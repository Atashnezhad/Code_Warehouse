


load amin

for i=1:10
    

plot(1,mat(1,i),'*');
end
